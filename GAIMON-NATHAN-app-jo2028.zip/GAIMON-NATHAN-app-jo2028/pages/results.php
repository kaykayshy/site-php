<?php
// Fichier : database/database.php
try {
    $host = 'localhost';
    $dbname = 'natan-gaimon-jo-2028'; // Ton nom de base exact
    $user = 'root'; 
    $password = 'root'; // MAMP demande souvent 'root'. Si ça plante, essaie '' (vide).
    
    // Création de la variable $pdo (C'est elle que results.php ne trouvait pas)
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
    
    // Activation des erreurs pour voir les pépins
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
} catch (Exception $e) {
    die("Erreur de connexion : " . $e->getMessage());
}
?>
<?php
// =================================================================
// ÉTAPE 1 : ON BRANCHE LA PRISE (VERSION BLINDÉE)
// =================================================================
// J'utilise __DIR__ pour forcer le chemin absolu. 
// Ça évite les erreurs de "fichier non trouvé" ou de mauvaise position.
require_once __DIR__ . '/../database/database.php';

try {
    // =================================================================
    // ÉTAPE 2 : LA REQUÊTE PUZZLE
    // =================================================================
    // On recupère : Nom de l'épreuve, Nom de l'athlète, et le Résultat
    $query = "SELECT nom_athlete, prenom_athlete, nom_epreuve, resultat 
              FROM PARTICIPER 
              INNER JOIN ATHLETE ON PARTICIPER.id_athlete = ATHLETE.id_athlete
              INNER JOIN EPREUVE ON PARTICIPER.id_epreuve = EPREUVE.id_epreuve
              ORDER BY nom_epreuve ASC";

    // Maintenant que database.php est bien chargé, $pdo existe.
    $statement = $pdo->query($query);
    $resultats = $statement->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    echo "Erreur SQL : " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Résultats des JO 2028</title>
    <link rel="stylesheet" href="../css/styles-computer.css">
    <link rel="stylesheet" href="../css/styles-responsive.css">
</head>
<body>
    <header>
        <nav>
            <!-- Menu vers les pages sports, events, et results -->
            <ul class="menu">
                <li><a href="../index.php">Accueil</a></li>
                <li><a href="sports.php">Sports</a></li>
                <li><a href="./events.php">Calendrier des épreuves</a></li>
                <li><a href="results.php">Résultats</a></li>
                <li><a href="./login.php">Accès administrateur</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h1>Résultats</h1>

        <?php 
        
         if (empty($resultats)):
        ?>
            <p>Pas encore de résultats enregistrés.</p>
        
        <?php else: ?>
            
            <table border="1">
                <thead>
                    <tr>
                        <th>Épreuve</th>
                        <th>Athlète</th>
                        <th>Performance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($resultats as $ligne): ?>
                        <tr>
                            <td><?= htmlspecialchars($ligne['nom_epreuve']) ?></td>
                            <td>
                                <?= htmlspecialchars($ligne['nom_athlete'] . ' ' . $ligne['prenom_athlete']) ?>
                            </td>
                            <td><?= htmlspecialchars($ligne['resultat']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

        <?php endif; ?>
         
        <p class="paragraph-link">
            <a class="link-home" href="../index.php">Retour Accueil</a>
        </p>
    </main>

    <footer>
          <figure>
            <img src="../img/logo-jo.png" alt="logo Jeux Olympiques - Los Angeles 2028">
        </figure>
    </footer>
</body>
</html>