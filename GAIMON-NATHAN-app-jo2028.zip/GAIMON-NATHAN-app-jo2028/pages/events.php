<?php
try {
    $host = 'localhost';
    $dbname = 'natan-gaimon-jo-2028';
    $user = 'root';
    $password = 'root';

    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (Exception $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

try {
    // Récupération des épreuves + lieux
    $query = "SELECT nom_epreuve, date_epreuve, heure_epreuve, nom_lieu 
              FROM EPREUVE 
              INNER JOIN LIEU ON EPREUVE.id_lieu = LIEU.id_lieu 
              ORDER BY date_epreuve ASC";

    $statement = $pdo->query($query);
    $epreuves = $statement->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    echo "Erreur SQL : " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Calendrier des Épreuves</title>
    <link rel="stylesheet" href="../css/normalize.css">
    <link rel="stylesheet" href="../css/styles-computer.css">
    <link rel="stylesheet" href="../css/styles-responsive.css">
</head>
<body>

<header>
    <nav>
        <ul class="menu">
            <li><a href="../index.php">Accueil</a></li>
            <li><a href="sports.php">Sports</a></li>
            <li><a href="./events.php">Calendrier des épreuves</a></li>
            <li><a href="results.php">Résultats</a></li>
            <li><a href="./login.php">Accès administrateur</a></li>
        </ul>
    </nav>
</header>

<main>
    <h1>Calendrier des Épreuves</h1>

    <?php
    if (count($epreuves) > 0) {
        echo "<table>";
        echo "<tr>
                <th class='color'>Épreuve</th>
                <th class='color'>Date</th>
                <th class='color'>Heure</th>
                <th class='color'>Lieu</th>
              </tr>";

        foreach ($epreuves as $epreuve) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($epreuve['nom_epreuve']) . "</td>";
            echo "<td>" . htmlspecialchars($epreuve['date_epreuve']) . "</td>";
            echo "<td>" . htmlspecialchars($epreuve['heure_epreuve']) . "</td>";
            echo "<td>" . htmlspecialchars($epreuve['nom_lieu']) . "</td>";
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "<p>Aucune épreuve trouvée.</p>";
    }
    ?>

    <p class="paragraph-link">
        <a class="link-home" href="../index.php">Retour Accueil</a>
    </p>

</main>

<footer>
    <figure>
        <img src="../img/logo-jo.png" alt="logo Jeux Olympiques - Los Angeles 2028">
    </figure>
</footer>

</body>
</html>
