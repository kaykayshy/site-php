<?php
session_start();
require_once("../../../database/database.php");

// Vérifiez si l'utilisateur est connecté
if (!isset($_SESSION['login'])) {
    header('Location: ../../../index.php');
    exit();
}

// Vérifiez si l'ID du sport est fourni dans l'URL
if (!isset($_GET['id_sport'])) {
    $_SESSION['error'] = "ID du sport manquant.";
    header("Location: manage-sports.php");
    exit();
}

$id_sport = filter_input(INPUT_GET, 'id_sport', FILTER_VALIDATE_INT);

// Vérifiez si l'ID du sport est un entier valide
if (!$id_sport && $id_sport !== 0) {
    $_SESSION['error'] = "ID du sport invalide.";
    header("Location: manage-sports.php");
    exit();
}

// Vider les messages de succès précédents
if (isset($_SESSION['success'])) {
    unset($_SESSION['success']);
}

// Récupérez les informations du sport pour affichage dans le formulaire
try {
    $querySport = "SELECT nom_sport FROM SPORT WHERE id_sport = :param_id_sport";
    $statementSport = $connexion->prepare($querySport);
    $statementSport->bindParam(":param_id_sport", $id_sport, PDO::PARAM_INT);
    $statementSport->execute();

    if ($statementSport->rowCount() > 0) {
        $sport = $statementSport->fetch(PDO::FETCH_ASSOC);
    } else {
        $_SESSION['error'] = "Sport non trouvé.";
        header("Location: manage-sports.php");
        exit();
    }
} catch (PDOException $e) {
    $_SESSION['error'] = "Erreur de base de données : " . $e->getMessage();
    header("Location: manage-sports.php");
    exit();
}

// Vérifiez si le formulaire est soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assurez-vous d'obtenir des données sécurisées et filtrées
    $nomSport = filter_input(INPUT_POST, 'nomSport', FILTER_SANITIZE_SPECIAL_CHARS);

    // Vérifiez si le nom du sport est vide
    if (empty($nomSport)) {
        $_SESSION['error'] = "Le nom du sport ne peut pas être vide.";
        header("Location: modify-sport.php?id_sport=$id_sport");
        exit();
    }

    try {
        // Vérifiez si le sport existe déjà
        $queryCheck = "SELECT id_sport FROM SPORT WHERE nom_sport = :nomSport AND id_sport <> :param_id_sport";
        $statementCheck = $connexion->prepare($queryCheck);
        $statementCheck->bindParam(":nomSport", $nomSport, PDO::PARAM_STR);
        $statementCheck->bindParam(":param_id_sport", $id_sport, PDO::PARAM_INT);
        $statementCheck->execute();

        if ($statementCheck->rowCount() > 0) {
            $_SESSION['error'] = "Le sport existe déjà.";
            header("Location: modify-sport.php?id_sport=$id_sport");
            exit();
        }

        // Requête pour mettre à jour le sport
        $query = "UPDATE SPORT SET nom_sport = :nomSport WHERE id_sport = :param_id_sport";
        $statement = $connexion->prepare($query);
        $statement->bindParam(":nomSport", $nomSport, PDO::PARAM_STR);
        $statement->bindParam(":param_id_sport", $id_sport, PDO::PARAM_INT);

        // Exécutez la requête
        if ($statement->execute()) {
            $_SESSION['success'] = "Le sport a été modifié avec succès.";
            header("Location: manage-sports.php");
            exit();
        } else {
            $_SESSION['error'] = "Erreur lors de la modification du sport.";
            header("Location: modify-sport.php?id_sport=$id_sport");
            exit();
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Erreur de base de données : " . $e->getMessage();
        header("Location: modify-sport.php?id_sport=$id_sport");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../../css/normalize.css">
    <link rel="stylesheet" href="../../../css/styles-computer.css">
    <link rel="stylesheet" href="../../../css/styles-responsive.css">
    <link rel="shortcut icon" href="../../../img/favicon.ico" type="image/x-icon">
    <title>Modifier un Sport - Jeux Olympiques - Los Angeles 2028</title>
</head>

<body>
<header>
    <nav>
        <!-- Menu vers les pages sports, events, et results -->
        <ul class="menu">
            <li><a href="/GAIMON-NATHAN-app-jo2028/pages/admin/admin.php">Accueil Administration</a></li>
            <li><a href="/GAIMON-NATHAN-app-jo2028/pages/admin/admin-sports/manage-sports.php">Gestion Sports</a></li>
            <li><a href="/GAIMON-NATHAN-app-jo2028/pages/admin/admin-places/manage-places.php">Gestion Lieux</a></li>
            <li><a href="/GAIMON-NATHAN-app-jo2028/pages/admin/admin-countries/manage-countries.php">Gestion Pays</a></li>
            <li><a href="/GAIMON-NATHAN-app-jo2028/pages/admin/admin-events/manage-events.php">Gestion Calendrier</a></li>
            <li><a href="/GAIMON-NATHAN-app-jo2028/pages/admin/admin-athletes/manage-athletes.php">Gestion Athlètes</a></li>
            <li><a href="/GAIMON-NATHAN-app-jo2028/pages/admin/admin-results/manage-results.php">Gestion Résultats</a></li>
            <li><a href="/GAIMON-NATHAN-app-jo2028/logout.php">Déconnexion</a></li>
        </ul>
    </nav>
</header>
    <main>
        <h1>Modifier un Sport</h1>
        
        <!-- Affichage des messages d'erreur ou de succès -->
        <?php
        if (isset($_SESSION['error'])) {
            echo '<p style="color: red;">' . $_SESSION['error'] . '</p>';
            unset($_SESSION['error']);
        }
        if (isset($_SESSION['success'])) {
            echo '<p style="color: green;">' . $_SESSION['success'] . '</p>';
            unset($_SESSION['success']);
        }
        ?>

        <form action="modify-sport.php?id_sport=<?php echo $id_sport; ?>" method="post"
            onsubmit="return confirm('Êtes-vous sûr de vouloir modifier ce sport?')">
            <label for="nomSport">Nom du Sport :</label>
            <input type="text" name="nomSport" id="nomSport"
                value="<?php echo htmlspecialchars($sport['nom_sport']); ?>" required>
            <input type="submit" value="Modifier le Sport">
        </form>

        <p class="paragraph-link">
            <a class="link-home" href="manage-sports.php">Retour à la gestion des sports</a>
        </p>
    </main>

    <footer>
        <figure>
            <img src="../../../img/logo-jo.png" alt="logo Jeux Olympiques - Los Angeles 2028">
        </figure>
    </footer>
</body>

</html>
