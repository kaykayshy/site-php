<?php
session_start();

// Vérifiez si l'utilisateur est connecté
if (!isset($_SESSION['login'])) {
    header('Location: ../../../index.php');
    exit();
}

$login = $_SESSION['login'];
$nom_utilisateur = $_SESSION['prenom_admin'];
$prenom_utilisateur = $_SESSION['nom_admin'];

// Fonction pour vérifier le token CSRF
function checkCSRFToken()
{
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            die('Token CSRF invalide.');
        }
    }
}

// Générer un token CSRF si ce n'est pas déjà fait
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// 🚮 SUPPRESSION SANS VÉRIFICATION DANS PARTICIPER
if (isset($_GET['delete_id'])) {
    require_once("../../../database/database.php");

    $id_event = filter_input(INPUT_GET, 'delete_id', FILTER_VALIDATE_INT);

    if ($id_event !== false) {
        try {
            // Récupérer le nom de l'événement
            $nameQuery = "SELECT title FROM events WHERE id_event = :id_event";
            $nameStatement = $connexion->prepare($nameQuery);
            $nameStatement->bindParam(':id_event', $id_event, PDO::PARAM_INT);
            $nameStatement->execute();
            $event = $nameStatement->fetch(PDO::FETCH_ASSOC);
            $title = $event['title'] ?? "l'événement";

            // 🔥 Suppression directe
            $sql = "DELETE FROM events WHERE id_event = :id_event";
            $statement = $connexion->prepare($sql);
            $statement->bindParam(':id_event', $id_event, PDO::PARAM_INT);
            $statement->execute();

            $_SESSION['success'] = "L'événement '" . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . "' a été supprimé avec succès.";

        } catch (PDOException $e) {
            $_SESSION['error'] = "Erreur lors de la suppression de l'événement : " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
        }
    }

    header('Location: manage-events.php');
    exit();
}
?>
